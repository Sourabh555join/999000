package com.manipal.model;

public class User {
private String username;
private String userlocation;


public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getUserlocation() {
	return userlocation;
}
public void setUserlocation(String userlocation) {
	this.userlocation = userlocation;
}

	
	
}
