package com.manipal.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.manipal.helper.UserResultextract;
import com.manipal.model.User;

public class UserDao {
  
	@Autowired
	JdbcTemplate  j1;

public JdbcTemplate getJ1() {
	return j1;
}

public void setJ1(JdbcTemplate j1) {
	this.j1 = j1;
}
	

//CREATE TABLE USER(USERNAME VARCHAR(25) NOT NULL,LOCATION VARCHAR(25));
   
public int addUser(User user) {
	String query="INSERT INTO USER VALUES (?,?)";
	int status=j1.update(query,user.getUsername(),user.getUserlocation());
	
	return status;
}

public List<User> getAllUser() {
	// TODO Auto-generated method stub
	String info="SELECT * FROM USER";
	List<User> l=j1.query(info, new UserResultextract());
	
	return l;
}


}
