package com.manipal.helper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.manipal.model.User;

public class UserResultextract implements ResultSetExtractor<List<User>>{

	public List<User> extractData(ResultSet rs) throws SQLException, DataAccessException {
		// TODO Auto-generated method stub
		
		List<User> l=new ArrayList<>();
		
		while(rs.next()) {
			User u=new User();
			u.setUsername(rs.getString(1));
			u.setUserlocation(rs.getString(2));
			l.add(u);
			
		}
		
		return l;
	}

}
