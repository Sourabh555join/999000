package com.manipal.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.manipal.dao.UserDao;
import com.manipal.model.User;



@Controller
@RequestMapping
public class WelcomeController {
	/*
	
	@RequestMapping(value="/Yahan_se_pakad",method=RequestMethod.GET)
	public ModelAndView greet() {
		ModelAndView m=new ModelAndView("greeting");
		
		
		return m;
	}
	*/
	@RequestMapping("/grahakForm")
	public String getForm() {
		return "UserName";
	}
	
	
	@Autowired
	UserDao userdao;
	
	
	@RequestMapping(value="/addUser" ,method=RequestMethod.POST)
	public String AddUserDetails(@ModelAttribute User u1) {
	userdao.addUser(u1);
		
		return "useradded";
	}

	@RequestMapping(value="/naam_Batao" ,method=RequestMethod.GET)
	public ModelAndView greetWithName(@ModelAttribute User u1) {
		ModelAndView m=new ModelAndView("swagatam" );
      m.addObject("user",u1);
		return m;
	}
	
	@RequestMapping(value="showUsers")
	public ModelAndView getUsers(){
		
		List<User> list=userdao.getAllUser();
		return new ModelAndView("userDetails","userlist",list);
		
		
	}
	
	/*
	@RequestMapping(value="/naam_Batao" ,method=RequestMethod.GET)
	public ModelAndView greetWithName(@RequestParam("shubhnam") String name,@RequestParam("ghar") String location) {
		ModelAndView m=new ModelAndView("swagatam" );
        User u1=new User();
        u1.setUsername(name);
        u1.setUserlocation(location);
        m.addObject("marry", u1);
		return m;
	}

	*/
	
	
	/*
	
	@RequestMapping(value="/naam_Batao" ,method=RequestMethod.GET)
	public ModelAndView greetWithName(@RequestParam("shubhnam") String name,@RequestParam("ghar") String location) {
		ModelAndView m=new ModelAndView("nayaGreeting" );
         m.addObject("name",name);
         m.addObject("location", location);
		return m;
	}

	*/
	
	/*
	@RequestMapping(value="/naam_Batao/{userName}/{location}" ,method=RequestMethod.GET)
	public ModelAndView greetWithName1(@PathVariable("userName") String name,@PathVariable("location") String location) {
		ModelAndView m=new ModelAndView("nayaGreeting" );
		 m.addObject("name",name);
         m.addObject("location", location);
		return m;
	}
	
	*/

}
