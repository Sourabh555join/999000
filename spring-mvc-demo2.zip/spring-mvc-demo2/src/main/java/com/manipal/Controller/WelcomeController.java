package com.manipal.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.manipal.model.User;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

@Controller
@RequestMapping
public class WelcomeController {
	
	
	@RequestMapping(value="/Yahan_se_pakad",method=RequestMethod.GET)
	public ModelAndView greet() {
		ModelAndView m=new ModelAndView("loginForm");
		
		
		return m;
	}
	
	/*
	
	@RequestMapping("/grahakForm")
	public String getForm() {
		return "UserName";
	}
	
	*/
	
	@RequestMapping(value="/naam_Batao" ,method=RequestMethod.GET)
	public ModelAndView greetWithName(@RequestParam("balak") String name,@RequestParam("code") String p) {
		ModelAndView m2=new ModelAndView("loginForm" );
        if(p.equals("admin123")) {
        	ModelAndView m=new ModelAndView("happyWelcome" );
        	m.addObject("name", name);
        	return m;
        }
		return m2;
	}

	
	
	
	/*
	
	@RequestMapping(value="/naam_Batao" ,method=RequestMethod.GET)
	public ModelAndView greetWithName(@RequestParam("shubhnam") String name,@RequestParam("ghar") String location) {
		ModelAndView m=new ModelAndView("nayaGreeting" );
         m.addObject("name",name);
         m.addObject("location", location);
		return m;
	}

	*/
	
	@RequestMapping(value="/naam_Batao/{userName}/{location}" ,method=RequestMethod.GET)
	public ModelAndView greetWithName1(@PathVariable("userName") String name,@PathVariable("location") String location) {
		ModelAndView m=new ModelAndView("nayaGreeting" );
		 m.addObject("name",name);
         m.addObject("location", location);
		return m;
	}

}
