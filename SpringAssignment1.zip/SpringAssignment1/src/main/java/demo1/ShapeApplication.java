package demo1;
import org.springframework.beans.factory.*;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.*;
import org.springframework.core.io.ClassPathResource;
import com.manipal.spring_core_demos.Triangle;
import com.manipal.spring_core_demos.Line;
import com.manipal.spring_core_demos.Point;
;
public class ShapeApplication {

	public static void main(String[] args) {
	//	BeanFactory factory=new XmlBeanFactory(new ClassPathResource("spring.xml"));
		
		
//		ApplicationContext factory=new ClassPathXmlApplicationContext("spring.xml");
//		
//		Welcome obj1=(Welcome) factory.getBean("welcome");
//	  System.out.println(obj1.getMessage());
//	  System.out.println();
//	  
//	  Welcome obj2=(Welcome) factory.getBean("welcome1");
//	  System.out.println(obj2.getMessage());
		
		BeanFactory shape=new XmlBeanFactory(new ClassPathResource("spring.xml"));
		Triangle t1=(Triangle) shape.getBean("tribhuj");
		//System.out.println(t1.getP1().getxCor()+" "+t1.getP2()+" "+t1.getP3());
		
		System.out.println();
		//BeanFactory shape2=new XmlBeanFactory(new ClassPathResource("spring.xml"));
		Line l1=(Line) shape.getBean("laxman_rekha");
//		System.out.println(l1.getP1()+" "+l1.getP2());
		
		Point p1=t1.getP1(),p2=t1.getP2(),p3=t1.getP3(),p4=l1.getP1(),p5=l1.getP2();
		System.out.println("for triangle");
		
			System.out.println(p1.getxCor()+" "+p1.getyCor());
			System.out.println(p2.getxCor()+" "+p2.getyCor());
			System.out.println(p3.getxCor()+" "+p3.getyCor());
		System.out.println("for line");
		System.out.println(p4.getxCor()+" "+p4.getyCor());
		System.out.println(p5.getxCor()+" "+p5.getyCor());
	}
	
}
